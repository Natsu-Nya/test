var gulp = require('gulp'),
     uglify = require('gulp-uglify'),
    // concat = require('gulp-concat'),
     rename = require('gulp-rename'),
     connect = require('gulp-connect'),//livereload
     sass = require('gulp-sass');
     sourcemaps = require( 'gulp-sourcemaps' );
     autoprefixer=require('gulp-autoprefixer');
     htmlmin = require('gulp-htmlmin');     

//自动生成路劲文件夹
var jsSrc = 'build/js/*.js';
var jsDist = 'dist/js';

var sassSrc = '../app/css/scss/*.scss';
var sassDist = '../app/css/css';

var htmlSrc = 'views/*.html';
var htmlDist = 'dist';

var cssSrc = 'views/*.html';
var cssDist = 'dist';

var mapSrc='../../maps';

 //定义名为js的任务
 gulp.task('js', function () {

     gulp.src(jsSrc)
         //.pipe(concat('main.js'))
         //.pipe(gulp.dest(jsDist))
         //.pipe(rename({suffix: '.min'}))
         .pipe(uglify({
           // mangle: true,//类型：Boolean 默认：true 是否修改变量名
           // compress: true,//类型：Boolean 默认：true 是否完全压缩
           // preserveComments: 'all' //保留所有注释
        }))
         .pipe(gulp.dest(jsDist))
         .pipe(connect.reload())

});

 //定义html任务
 gulp.task('html', function () {

    connect.reload();

});

//定义sass任务
gulp.task('sass', function () {
return gulp.src(sassSrc)
.pipe(sourcemaps.init()) //初始化
.pipe(sass({outputStyle:'expanded'}).on('error', sass.logError))
.pipe(autoprefixer({
      browsers: ['last 2 version'],
      cascade: false//美化
    }))
//.pipe(sourcemaps.write(mapSrc)) //生成sourcemap文件，路径为mapSrc
.pipe(gulp.dest(sassDist));
});

// sass四中编译风格
// expanded 展开
// nested 继承
// compact 紧凑
// compressed 压缩

 //定义css任务
 gulp.task('css', function () {

    gulp.src(cssSrc)
        .pipe(connect.reload());

});


//定义livereload任务
 gulp.task('connect', function () {
     connect.server({
        root: '',
        port: 3000,
        livereload: true
    });
 });


 //定义看守任务
 gulp.task('watch', function () {

     gulp.watch(htmlSrc, ['html']);

    gulp.watch(jsSrc, ['js']);

    gulp.watch(sassSrc, ['sass']);

    gulp.watch(cssSrc, ['css']);

 });


gulp.task('minSpt', function() {
    gulp.src('./wwwroot/lib/jquery-weui-1.0.1/src/js/*.js')
        //.pipe(concat('all.js'))
        //.pipe(gulp.dest('./minSpt'))
        //.pipe(rename('all.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest('./wwwroot/lib/jquery-weui-1.0.1/src/jsmin'));
});

 gulp.task('htmlmin', function () {
    var options = {
        removeComments: true,//清除HTML注释
        collapseWhitespace: true,//压缩HTML
        collapseBooleanAttributes: true,//省略布尔属性的值 <input checked="true"/> ==> <input />
        removeEmptyAttributes: true,//删除所有空格作属性值 <input id="" /> ==> <input />
        removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
        removeStyleLinkTypeAttributes: true,//删除<style>和<link>的type="text/css"
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    };
    gulp.src('build/*.cshtml')
        .pipe(htmlmin(options))
        .pipe(rename({suffix:".min"}))
        .pipe(gulp.dest('build'));
});


 //定义默认任务
 //gulp.task('default', [ 'js', 'html','sass','css','watch']);//'connect'
 gulp.task('default', [ 'sass','watch']);//'connect'